# Tower Blocks

A Pen created on CodePen.

Original URL: [https://codepen.io/vishwak-Varma/pen/ByLwrmb](https://codepen.io/vishwak-Varma/pen/ByLwrmb).

Tower building game. Place blocks by clicking, tapping or spacebarring. 

A clone of Stack https://itunes.apple.com/us/app/stack/id1080487957?mt=8